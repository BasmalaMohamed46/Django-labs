from .models import Book

def create_book(title, desc, rate, views=0, user=None, categories=None):
    book = Book.objects.create(title=title, desc=desc, rate=rate, views=views, user=user)
    if categories:
        book.categories.set(categories)
    return book

def get_all_books():
    return Book.objects.all()

def get_book_by_id(book_id):
    try:
        return Book.objects.get(pk=book_id)
    except Book.DoesNotExist:
        return None

def update_book(book_id, title=None, desc=None, rate=None, views=None, user=None, categories=None):
    book = get_book_by_id(book_id)
    if book:
        if title is not None:
            book.title = title
        if desc is not None:
            book.desc = desc
        if rate is not None:
            book.rate = rate
        if views is not None:
            book.views = views
        if user is not None:
            book.user = user
        if categories is not None:
            book.categories.set(categories)
        book.save()
        return book
    return None

def delete_book(book_id):
    book = get_book_by_id(book_id)
    if book:
        book.delete()
        return True
    return False
