from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, authenticate
from .models import Book
from .crud_operations import create_book, get_all_books, get_book_by_id, update_book, delete_book

def book_list(request):
    books = get_all_books()
    return render(request, "bookstore/book_list.html", {"books": books})

def book_details(request, book_id):
    book = get_book_by_id(book_id)
    return render(request, "bookstore/book_details.html", {"book": book})

def book_delete(request, book_id):
    if request.method == "POST":
        delete_book(book_id)
        return redirect("bookstore:book-list")
    else:
        return redirect("bookstore:book-list")

def book_update(request, book_id):
    book = get_book_by_id(book_id)
    if request.method == "POST":
        title = request.POST.get("title")
        desc = request.POST.get("desc")
        rate = request.POST.get("rate")
        views = request.POST.get("views")
        update_book(book_id, title=title, desc=desc, rate=rate, views=views)
        return redirect("bookstore:book-list")
    return render(request, "bookstore/book_update.html", {"book": book})

def book_create(request):
    if request.method == "POST":
        title = request.POST.get("title")
        desc = request.POST.get("desc")
        rate = request.POST.get("rate")
        views = request.POST.get("views")
        user = request.user 
        create_book(title=title, desc=desc, rate=rate, views=views, user=user)
        return redirect("bookstore:book-list")
    return render(request, "bookstore/book_create.html")

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("bookstore:book-list")
    else:
        form = AuthenticationForm()
    return render(request, 'bookstore/login.html', {'form': form})

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('bookstore:book-list')
    else:
        form = UserCreationForm()
    return render(request, 'bookstore/signup.html', {'form': form})
